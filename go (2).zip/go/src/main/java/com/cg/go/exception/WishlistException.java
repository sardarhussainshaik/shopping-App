package com.cg.go.exception;

public class WishlistException extends Exception {

	private static final long serialVersionUID = 1L;

	public WishlistException(String msg) {
		super(msg);
	}

}
