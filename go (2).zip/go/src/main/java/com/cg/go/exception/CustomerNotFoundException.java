package com.cg.go.exception;


	public class CustomerNotFoundException extends Exception {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1970762601225780363L;

		public CustomerNotFoundException(String message)
		{
			super(message);
		}
	}


