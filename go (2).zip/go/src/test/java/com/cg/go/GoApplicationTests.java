package com.cg.go;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoApplicationTests {

	@Test
	void contextLoads() {
	}

}
